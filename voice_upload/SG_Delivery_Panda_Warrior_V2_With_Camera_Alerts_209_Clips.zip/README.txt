SG DELIVERY — PANDA WARRIOR V2
185 MP3 recordings: 67 original + 118 new ElevenLabs clips.
Original 67 audio bytes preserved. New clips cut from four user-supplied recordings.

INTEGRATION
Copy audio/ and manifest.json to the existing Panda Warrior asset directory. The old V1 loader may require exactly 67 clips; update it to accept the versioned manifest and validate all 185 IDs/files.
Use full recorded instructions first. For new distances, combine distance_in_3km + turn_right, etc. Prefer standalone distance phrases over assembled numeric tokens.
For decimal distances, compose word_in + number_3 + word_point + number_7 + unit_kilometres + turn_right, with controlled gaps and verified distance. For compound integers, compose number_20 + number_3 (23), etc. Handle singular units (use existing distance_in_1km or add singular unit clips if needed).
For exit 17B use take_exit_number + number_17 + letter_b only when route metadata confirms the actual exit. Do not infer lane or destination. Roundabout exit 1–10 supported.
Never substitute an inaccurate distance, exit or maneuver. Unsupported road names remain visual unless additional Panda Warrior recordings are obtained. No female TTS.
Prepare complete phrases asynchronously; playback must not block rerouting. Cancel all stale clips when route changes, prioritize urgent maneuvers, deduplicate cues. Use distance threshold crossing and prevent late or premature turn cues.
Test all clips for semantic accuracy, pronunciation and clean boundaries on device. This is an audio asset package, not an APK or completed navigation engine. Confirm applicable ElevenLabs distribution rights before sharing with runners.


CAMERA ALERT EXTENSION
SG DELIVERY — PANDA WARRIOR V2 CAMERA ALERT EXTENSION
====================================================
24 NEW ElevenLabs MP3 clips from the user's three provided recordings:
- 10 Batch 1 warnings
- 10 Batch 2 advanced warnings
- 4 short modular phrases

Audio cut points were placed in extended silences between complete voice lines.
Original voice preserved without artificial regeneration or TTS replacement.
No prior V2 navigation clip is removed or modified.

INTEGRATION:
Extract audio/camera_alerts/ into the SG Delivery bundled Panda Warrior voice assets.
See manifest.json for ID, filename, spoken text, category, and duration.
Do not play all variations for one camera; select only the applicable warning.
Build voice controller routing from verified camera category, road/direction, and approach distance.
Use verified road speed limits only. Never invent live mobile enforcement status.
Do not announce "You're above the verified speed limit" unless a valid limit is actually verified.
Do not let warnings interrupt urgent turn or expressway exit guidance.
Existing 185 clips + these 24 clips = 209 total standalone recordings.

This ZIP is an AUDIO PACK only. It does NOT implement app logic, cameras or APK changes.
Sample and review the clipped audio on a real device before production integration.
